SingleFile 1.37.0 对应源码材料

内容
upstream/SingleFile-MV3-v1.37.0.zip：作者 v1.37.0 tag 完整官方归档，保留原始字节和全部文件。
upstream/single-file-core-v1.12.0.zip：作者 v1.12.0 tag 完整官方归档，保留原始字节和全部文件。
LICENSE.txt：SingleFile-MV3 v1.37.0 上游 AGPL v3 原文。
NOTICE.txt：真实作者、来源、许可与未执行项说明。

来源
SingleFile-MV3 v1.37.0
https://github.com/gildas-lormeau/SingleFile-MV3/tree/v1.37.0
https://codeload.github.com/gildas-lormeau/SingleFile-MV3/zip/refs/tags/v1.37.0
single-file-core v1.12.0
https://github.com/gildas-lormeau/single-file-core/tree/v1.12.0
https://codeload.github.com/gildas-lormeau/single-file-core/zip/refs/tags/v1.12.0
官方 Chromium 安装包
https://github.com/gildas-lormeau/SingleFile-MV3/releases/download/v1.37.0/singlefile-extension-chromium.zip

对应关系
原安装包根 manifest.json 和 MV3 tag 的 manifest.json 都声明扩展版本1.37.0。
MV3 package-lock.json 锁定 single-file-core 1.12.0，与第二份归档 package.json 相符。
MV3 package.json 的项目包版本1.0.0不是浏览器扩展版本，不用于选择安装包。
build-extension.sh 调用 npm ci、build.sh，再将 manifest.json、lib、_locales、src 封装为 singlefile-extension-chromium.zip。
应完整保留源码树中的许可、构建脚本、锁文件、版权、第三方声明和 vendor 内容。

重建入口（只提供说明，未执行）
1. 解压 SingleFile-MV3-v1.37.0.zip，进入 SingleFile-MV3-1.37.0 目录。
2. 准备 Bash、zip、jq 和满足锁文件内开发工具引擎要求的 Node.js/npm 环境。
3. 上游入口为 npm run build，调用 build-extension.sh；脚本会运行 npm ci，联网获取 package-lock.json 锁定的依赖，再调用 build.sh 进行 Rollup 构建并打包 Chromium/Edge 扩展。
4. single-file-core 完整源码已另附。npm ci 使用的发布依赖地址在上游锁文件中：
https://registry.npmjs.org/single-file-core/-/single-file-core-1.12.0.tgz
本材料不包含 node_modules；开发工具和构建依赖仍按原锁文件获取，不应改用未锁定的最新依赖。
5. 上游打包脚本包含可选外部服务配置注入，公开 tag 不代表作者发布时的全部外部构建输入。不要从分发包提取或公开凭据，也不要据此承诺逐字节可重复构建。

使用与验证边界
两份 tag 归档用于提供对应源码，不是面向使用者的安装ZIP。安装使用外部的 singlefile-extension-chromium-1.37.0.zip，按浏览器加载已解压扩展的步骤操作。
整理过程只核对归档可读、完整条目、源码必要文件、版本、锁定依赖和许可证，不执行任何上游脚本或 npm 命令。
未执行依赖安装、未重新构建、未验证重建产物与原包逐字节一致、未上传或部署。
